<?php

namespace Client\Foundations;


class Collection
{
    public static function getNetAmount($amount)
    {


        $current_amount = $amount->sum('amount');

        return ($current_amount - (2 * $amount->count())) / 1.05;

    }
}
