<?php

use Admin\Http\Controllers\Views\Country\CityController;
use Admin\Http\Controllers\Views\Country\CountryController;
use Admin\Http\Controllers\Views\Country\DistrictController;
use Admin\Http\Controllers\Views\Country\GovernorateController;
use Admin\Http\Controllers\Views\Country\ZoneController;
use Illuminate\Support\Facades\Route;


Route::group([
     'middleware' => 'auth:sanctum',
], function () {

     Route::get('countries', [CountryController::class, 'index']);

     Route::get('countries/search', [CountryController::class, 'search']);

     Route::get('country/create', [CountryController::class, 'create']);

     Route::post('country', [CountryController::class, 'store']);

     Route::get('country/{country}', [CountryController::class, 'show']);

     Route::get('country/edit/{country}', [CountryController::class, 'edit']);

     Route::patch('country/{country}', [CountryController::class, 'update']);

     Route::delete('country/{country}', [CountryController::class, 'destroy']);

     Route::any('country/delete/{country}', [CountryController::class, 'destroy']);

     Route::any('country-active/{country}', [CountryController::class, 'active']);

     Route::any('country-inactive/{country}', [CountryController::class, 'inactive']);


     Route::get('governorates/{country}', [GovernorateController::class, 'index']);

     Route::get('governorates/search/{country}', [GovernorateController::class, 'search']);

     Route::get('governorates-search-all', [GovernorateController::class, 'searchAll']);

     Route::get('country-governorates/{country}', [GovernorateController::class, 'countryGovernorates']);

     Route::get('governorate/create', [GovernorateController::class, 'create']);

     Route::post('governorate', [GovernorateController::class, 'store']);

     Route::get('governorate/{governorate}', [GovernorateController::class, 'show']);

     Route::get('governorate/edit/{governorate}', [GovernorateController::class, 'edit']);

     Route::patch('governorate/{governorate}', [GovernorateController::class, 'update']);

     Route::delete('governorate/{governorate}', [GovernorateController::class, 'destroy']);

     Route::any('governorate-active/{governorate}', [GovernorateController::class, 'active']);

     Route::any('governorate-inactive/{governorate}', [GovernorateController::class, 'inactive']);


     Route::get('cities/{governorate}', [CityController::class, 'index']);

     Route::get('cities/search/{governorate}', [CityController::class, 'search']);

     Route::get('cities-search-all', [CityController::class, 'searchAll']);

     Route::post('city', [CityController::class, 'store']);

     Route::get('city/{city}', [CityController::class, 'show']);

     Route::patch('city/{city}', [CityController::class, 'update']);

     Route::delete('city/{city}', [CityController::class, 'destroy']);


     Route::get('zones/{city}', [ZoneController::class, 'index']);

     Route::get('zones/search/{city}', [ZoneController::class, 'search']);

     Route::get('zones-search-all', [ZoneController::class, 'searchAll']);

     Route::post('zone', [ZoneController::class, 'store']);

     Route::get('zone/{zone}', [ZoneController::class, 'show']);

     Route::patch('zone/{zone}', [ZoneController::class, 'update']);

     Route::delete('zone/{zone}', [ZoneController::class, 'destroy']);


     Route::get('districts/{zone}', [DistrictController::class, 'index']);

     Route::get('districts/search/{zone}', [DistrictController::class, 'search']);

     Route::get('districts-search-all', [DistrictController::class, 'searchAll']);

     Route::post('district', [DistrictController::class, 'store']);

     Route::get('district/{district}', [DistrictController::class, 'show']);

     Route::patch('district/{district}', [DistrictController::class, 'update']);

     Route::delete('district/{district}', [DistrictController::class, 'destroy']);
});
