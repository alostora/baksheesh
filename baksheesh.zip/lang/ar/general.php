<?php

return [

    "app_name" => "Tipo Smart",

    "online" => "Online",

    "dashboard" => "Dashboard",

    "current_status" => "الحالة الحالية",

    "active" => "نشط",

    "inactive" => "غير نشط",

    "total" => "الاجمالي",

    "wallet" => "المحفظه",
    "good" => "جيد",
    "bad" => "سئ",

];
