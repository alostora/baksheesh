<?php

return [

    'page_title' => 'الملف الشخصي',

    'general' => 'عام',

    'update_profile_request' => 'طلب تحديث',

    'update_password' => 'تحديث كلمة المرور',

    'country' => 'الدولة',

    'governorate' => 'المدينة',

    'phone' => 'الهاتف',

    'email' => 'البريد الالكتروني',

    'available_companies_count' => 'عدد الشركات المتاح',

    'available_employees_count' => 'عدد الموظفون المتاح',

    'new_password' => 'كلمة المرور الجديده',

    'confirm_new_password' => 'تأكيد كلمة المرور الجديده',

];
