<?php

return [

    'page_title' => 'التقيم المتاح للشركات',

    'name' => 'الاسم',

    'name_ar' => 'الاسم عربي',

    'company' => 'الشركة',



    //operatoins
    "operations" => "اجراءات",

    "create" => "اضافة تقييم",

    "update" => "تعديل بيانات التقييم",

    "submit" => "حفظ",

    "search" => "بحث",

    "empty" => "فارغ",
    "current_status" => "الحالة الحالية",
    "active" => "نشط",
    "inactive" => "غير نشط",
];
