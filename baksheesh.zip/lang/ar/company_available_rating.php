<?php

return [

    'page_title' => 'التقيم المتاح للشركات',


    'name' => '(EN)اسم التقييم',

    'name_ar' => 'اسم التقييم (عربي)',

    'company' => 'الشركة',



    //operatoins
    "operations" => "اجراءات",

    "create" => "اضافة تقييم شركة",

    "update" => "تعديل بيانات التقييم",

    "submit" => "حفظ",

    "search" => "بحث",

    "empty" => "فارغ",
    "current_status" => "الحالة الحالية",
    "active" => "نشط",
    "inactive" => "غير نشط",

    "client" => "العميل",
];
