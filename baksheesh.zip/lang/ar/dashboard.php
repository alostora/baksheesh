<?php

return [

    "app_name" => "Tipo Smart",

    "online" => "متصل",

    "logout" => "خروج",

    "dashboard" => "لوحة التحكم",

    "active_clients" => "العملاء النشطون",

    "active_companies" => "الشركات النشطة",

    "active_employees" => "الموظفون النشطون",

    "month_income" => "اجمالي الدخل الشهري",

    "year_income" => "اجمالي الدخل السنوي",

    "current_amount" => "المبلغ الحالي",

    "current_status" => "الحالة الحالية",

    "active" => "نشط",

    "inactive" => "غير نشط",

    "profile" => "الملف الشخصي",

    "quick_start" => "ابدا الان",

];
