<?php

return [

    "filter" => "فلتر",

    "clients" => "العملاء",

    "select" => "اختر",

    "status" => "الحالة",

    "query_string" => "كلمة البحث",

    "search" => "بحث",

    "date_from" => "تاريخ من",

    "date_to" => "تاريخ الي",

    "employees" => "الموظفون",

    "companies" => "الشركات",

    "user_account_type" => "نوع الحساب",

    "countries" => "الدول",

    "rating_value" => "قيمة التقييم",

    "all" => "الكل",

    "active" => "نشط",

    "inactive" => "غير نشط",
    "good" => "جيد",
    "bad" => "سئ",

];
