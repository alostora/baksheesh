<?php

return [

    'page_title' => 'Companies',

    'filter' => 'Filter',

    'query_string' => 'Query String',

    'select' => 'Select',

    'name' => 'Name',

    'name_ar' => 'Name (AR)',

    'client' => 'Client',

    'employees' => 'Employees',

    'available_rating' => 'Available Rating',

    'demo_link' => 'Demo Link',

    'qr' => 'QR Code',

    "file" => "Image",

    "company_field" => "Company Field",


    //operatoins
    "operations" => "Operations",

    "create" => "Create Company",

    "update" => "Update Company",

    "submit" => "Submit",

    "search" => "Search",

    "empty" => "Empty",
    "current_status" => "Current Status",
    "active" => "Active",
    "inactive" => "Inactive",
];
