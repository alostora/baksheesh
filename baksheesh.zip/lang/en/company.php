<?php

return [

    'page_title' => 'Companies',

    'filter' => 'Filter',

    'query_string' => 'Query String',

    'select' => 'Select',

    'name' => 'Company Name',

    'name_ar' => 'Name (Ar)',

    'client' => 'Client Name',

    'employees' => 'Employees',

    'available_rating' => 'Available Rating',

    'demo_link' => 'Demo Link',

    'qr' => 'QR Code',

    "file" => "Logo",

    "company_field" => "Company Field",


    //operatoins
    "operations" => "Operations",

    "create" => "Create Company",

    "update" => "Update Company",

    "submit" => "Submit",

    "search" => "Search",

    "empty" => "Empty",
    "current_status" => "Current Status",
    "active" => "Active",
    "inactive" => "Inactive",

    "employees_qr" => "Qr Company Employees",
];
