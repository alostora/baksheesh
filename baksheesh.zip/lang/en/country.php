<?php

return [

    'page_title' => 'Countries',

    'filter' => 'Filter',

    'query_string' => 'Query String',

    'select' => 'Select',

    'name' => 'Name',

    'name_ar' => 'Name (AR)',

    'governorates' => 'Cities',

    //operatoins
    "operations" => "Operations",

    "create" => "Create Country",

    "update" => "Update Country",

    "submit" => "Submit",

    "search" => "Search",

    "empty" => "Empty",

    "current_status" => "Current Status",

    "active" => "Active",

    "inactive" => "Inactive",
];
