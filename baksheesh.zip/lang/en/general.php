<?php

return [

    "app_name" => "Tipo Smart",

    "online" => "Online",

    "dashboard" => "Dashboard",

    "current_status" => "Current Status",

    "active" => "Active",

    "inactive" => "Inactive",

    "total" => "Total",

    "wallet" => "Wallet",

    "good" => "Good",
    "bad" => "Bad",

];
