<?php

return [

    'page_title' => 'Profile',

    'general' => 'General',

    'update_profile_request' => 'Update Profile Request',

    'update_password' => 'Update Password',

    'country' => 'Country',

    'governorate' => 'Governorate',

    'phone' => 'Phone',

    'email' => 'Email',

    'available_companies_count' => 'Available Companies Count',

    'available_employees_count' => 'Available Employees Count',

    'new_password' => 'New Password',

    'confirm_new_password' => 'confirm New Password',

];
