<?php

return [

    'page_title' => 'Governorates',

    'filter' => 'Filter',

    'query_string' => 'Query String',

    'select' => 'Select',

    'country' => 'Country',

    'name' => 'City Name (En)',

    'name_ar' => 'City Name (Ar)',

    //operatoins
    "operations" => "Operations",

    "create" => "Create City",

    "update" => "Update City",

    "submit" => "Submit",

    "search" => "Search",

    "empty" => "Empty",
    "current_status" => "Current Status",
    "active" => "Active",
    "inactive" => "Inactive",
];
