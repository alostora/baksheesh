<?php

return [

    'page_title' => 'Governorates',

    'filter' => 'Filter',

    'query_string' => 'Query String',

    'select' => 'Select',

    'country' => 'Country',

    'name' => 'Name',

    'name_ar' => 'Name (AR)',

    //operatoins
    "operations" => "Operations",

    "create" => "Create City",

    "update" => "Update Governorate",

    "submit" => "Submit",

    "search" => "Search",

    "empty" => "Empty",
    "current_status" => "Current Status",
    "active" => "Active",
    "inactive" => "Inactive",
];
