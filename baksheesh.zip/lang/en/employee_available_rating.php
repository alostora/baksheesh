<?php

return [

    'page_title' => 'Employee Available Rating',

    'name' => 'Rating Name (En)',

    'name_ar' => 'Rating Name (ar)',

    'company' => 'Company',

    'employee' => 'Employee',

    'employees' => 'Employees',



    //operatoins
    "operations" => "Operations",

    "create" => "Create Rating",

    "update" => "Update City",

    "submit" => "Submit",

    "search" => "Search",

    "empty" => "Empty",
    "current_status" => "Current Status",
    "active" => "Active",
    "inactive" => "Inactive",
    "client" => "Client",
];
