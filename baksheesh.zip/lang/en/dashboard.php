<?php

return [

    "app_name" => "Tips",

    "online" => "Online",

    "logout" => "Logout",

    "dashboard" => "Dashboard",

    "active_clients" => "Active Clients",

    "active_companies" => "Active Companies",

    "active_employees" => "Active Employees",

    "month_income" => "Month Income",

    "year_income" => "Year Income",

    "current_amount" => "Current Amount",

    "profile" => "Profile",
    "quick_start" => "Quick start",
];
