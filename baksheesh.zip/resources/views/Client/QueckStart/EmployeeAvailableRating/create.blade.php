
@include('Main.header')
@include('Main.sidebar')
@include('Client.QueckStart.EmployeeAvailableRating.Views.create')
 @include('Main.footer')
