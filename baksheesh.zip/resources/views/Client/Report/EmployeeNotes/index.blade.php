@include('Main.header')
@include('Main.sidebar')
@include('Client.Report.EmployeeNotes.Views.table')
@include('Main.footer')