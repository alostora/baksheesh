@include('Main.header')
@include('Main.sidebar')
@include('Client.Report.CompanyNotes.Views.table')
@include('Main.footer')
