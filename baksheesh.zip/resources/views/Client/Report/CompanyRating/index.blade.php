@include('Main.header')
@include('Main.sidebar')
@include('Client.Report.CompanyRating.Views.table')
@include('Main.footer')
