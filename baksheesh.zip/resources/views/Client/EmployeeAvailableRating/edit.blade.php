@include('Main.header')
@include('Main.sidebar')
@include('Client.EmployeeAvailableRating.Views.edit')
@include('Main.footer')
