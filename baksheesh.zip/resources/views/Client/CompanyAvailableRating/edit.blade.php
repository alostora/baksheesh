@include('Main.header')
@include('Main.sidebar')
@include('Client.CompanyAvailableRating.Views.edit')
@include('Main.footer')
