@include('Main.header')
@include('Main.sidebar')
@include('Client.CompanyAvailableRating.Views.create')
@include('Main.footer')
