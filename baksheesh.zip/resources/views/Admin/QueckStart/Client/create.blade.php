
@include('Main.header')
@include('Main.sidebar')
@include('Admin.QueckStart.Client.Views.create')
 @include('Main.footer')
