
@include('Main.header')
@include('Main.sidebar')
@include('Admin.Client.Views.table')
 @include('Main.footer')
