
@include('Main.header')
@include('Main.sidebar')
@include('Admin.Client.Views.edit')
@include('Main.footer')
