@include('Main.header')
@include('Main.sidebar')
@include('Admin.CompanyAvailableRating.Views.edit')
@include('Main.footer')
