@include('Main.header')
@include('Main.sidebar')
@include('Admin.CompanyAvailableRating.Views.create')
@include('Main.footer')
