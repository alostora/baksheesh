@include('Main.header')
@include('Main.sidebar')
@include('Admin.CompanyAvailableRating.Views.table')
@include('Main.footer')
