@include('Main.header')
@include('Main.sidebar')
@include('Admin.Report.WithdrawalRequest.Views.table')
@include('Main.footer')