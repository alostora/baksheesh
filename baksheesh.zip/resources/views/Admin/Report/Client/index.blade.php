
@include('Main.header')
@include('Main.sidebar')
@include('Admin.Report.Client.Views.table')
 @include('Main.footer')
