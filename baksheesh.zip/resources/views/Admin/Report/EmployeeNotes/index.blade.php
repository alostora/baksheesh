@include('Main.header')
@include('Main.sidebar')
@include('Admin.Report.EmployeeNotes.Views.table')
@include('Main.footer')
