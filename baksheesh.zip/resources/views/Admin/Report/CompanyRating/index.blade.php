@include('Main.header')
@include('Main.sidebar')
@include('Admin.Report.CompanyRating.Views.table')
@include('Main.footer')
