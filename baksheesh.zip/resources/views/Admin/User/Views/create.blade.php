<!-- Main content -->
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title col-md-8">@lang('user.create')</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form role="form" action="{{url('admin/user')}}" method="POST">
                    @csrf
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group">
                                <div class="col-md-6">
                                    <label for="user_account_type_id">@lang('user.user_account_type')</label>
                                    <select required class="form-control" name="user_account_type_id" id="user_account_type_id">
                                        @foreach ($user_account_types as $account_type)
                                        <option value="{{$account_type->id}}">{{$account_type->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-6">

                                    <label for="name">@lang('user.name')</label>
                                    <input required type="text" class="form-control" name="name" id="name" placeholder="@lang('user.name')">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <div class="col-md-6">
                                    <label for="email">@lang('user.email')</label>
                                    <input required type="email" class="form-control" name="email" id="email" placeholder="@lang('user.email')">
                                </div>
                                <div class="col-md-6">
                                    <label for="phone">@lang('user.phone')</label>
                                    <input required type="text" class="form-control" name="phone" id="phone" placeholder="@lang('user.phone')">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <div class="col-md-6">
                                    <label for="password">@lang('user.password')</label>
                                    <input required type="password" class="form-control" name="password" id="password" placeholder="@lang('user.password')">
                                </div>
                            </div>
                        </div>

                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">@lang('user.submit')</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->



        </div>

    </div>
    <!-- /.row -->
</section>
<!-- /.content -->
