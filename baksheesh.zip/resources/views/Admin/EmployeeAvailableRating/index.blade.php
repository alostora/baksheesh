@include('Main.header')
@include('Main.sidebar')
@include('Admin.EmployeeAvailableRating.Views.table')
@include('Main.footer')
